package com.example.madcompetition.BackEnd;

import com.example.madcompetition.Message;

public class LocationMessage extends Message {

    public LocationMessage()
    {
        super();
    }

}
