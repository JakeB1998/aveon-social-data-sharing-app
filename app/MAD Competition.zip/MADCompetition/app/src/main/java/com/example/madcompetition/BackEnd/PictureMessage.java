package com.example.madcompetition.BackEnd;

import com.example.madcompetition.Message;

public class PictureMessage extends Message {

    public PictureMessage()
    {
        super();
    }
}
