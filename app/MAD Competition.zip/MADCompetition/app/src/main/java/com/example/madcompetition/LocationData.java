package com.example.madcompetition;

import android.location.Geocoder;
import android.location.Location;

import java.io.Serializable;

public class LocationData implements Serializable
{

    private double longitude;
    private double latitude;
    private String adress;
    private String accuracy;
    private String country;
    private String provider;
    private String postalCode;





    public LocationData()
    {}
    public LocationData(Location location)
    {
        this.longitude = location.getLongitude();
        this.latitude = location.getLatitude();
        this.accuracy = Float.toString(location.getAccuracy());


    }
    public LocationData(Location location, Geocoder geo)
    {
        this.longitude = location.getLongitude();
        this.latitude = location.getLatitude();
        this.accuracy = Float.toString(location.getAccuracy());


    }


    public void setLocationData(Geocoder geo)
    {}





}
