package com.example.madcompetition;

class UserPhotoGallaryInterface {
    private static final UserPhotoGallaryInterface ourInstance = new UserPhotoGallaryInterface();

    static UserPhotoGallaryInterface getInstance() {
        return ourInstance;
    }

    private UserPhotoGallaryInterface() {
    }


    public void selectPhotoFromGalllary()
    {

    }

}
