package com.example.madcompetition.BackEnd;

import java.io.Serializable;
import java.net.Inet4Address;

public class AccountInformation implements Serializable {

    private byte[] accountDataPayload;
    private Credentials accountCred;
    private Inet4Address adressInfo;
    private String ass;

    public AccountInformation()
    {
        ass = "sji0ijonood0";
    }
    public AccountInformation(Inet4Address adress)
    {
        this.adressInfo = adress;
    }

    public AccountInformation(Inet4Address adressInfo, Credentials accountCred)
    {
        this.adressInfo = adressInfo;
        this.accountCred = accountCred;

    }

    public byte[] getAccountDataPayload() {
        return accountDataPayload;
    }

    public void setAccountDataPayload(byte[] accountDataPayload) {
        this.accountDataPayload = accountDataPayload;
    }

    public Credentials getAccountcred() {
        return accountCred;
    }

    public void setAccountcred(Credentials accountcred) {
        this.accountCred = accountcred;
    }

    public Inet4Address getAdressInfo() {
        return adressInfo;
    }

    public void setAdressInfo(Inet4Address adressInfo) {
        this.adressInfo = adressInfo;
    }
}
