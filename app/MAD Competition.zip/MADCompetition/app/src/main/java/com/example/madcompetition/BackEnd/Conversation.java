package com.example.madcompetition.BackEnd;

import android.util.Log;

import com.example.madcompetition.BackEnd.Account;
import com.example.madcompetition.Message;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

public class Conversation implements Serializable
{
    private int conversationID;
    private final int ID_LENGTH = 6;
    private Account[] accounts;
    private ArrayList<Message> messages;



            public Conversation()
            {
                conversationID  = generateAccountID();
                setMessages(new ArrayList<Message>(0));

            }
    public Conversation(Account[] accounts)
    {
        this();
        this.setAccounts(accounts);

    }

    private int generateAccountID()
    {
        if (getConversationID() == -1)
        {
            String id1 = "";
            int id = 0;
            Random ran = new Random();
            for (int i = 0; i < ID_LENGTH; i++)
            {
                id1 += Integer.toString(ran.nextInt(9));
            }

            Log.i("Mine", "Account Id: " + id1.toString());
            id = Integer.parseInt((id1));
            return id;
        }

        return -1;
    }

    public Account[] getAccounts() {
        return accounts;
    }

    public void setAccounts(Account[] accounts) {
        this.accounts = accounts;
    }



    public int getConversationID() {
        return conversationID;
    }

    public void setConversationID(int conversationID) {
        this.conversationID = conversationID;
    }

    public ArrayList<Message> getMessages() {
        return messages;
    }

    public void setMessages(ArrayList<Message> messages) {
        this.messages = messages;
    }

    public void addMessage(Message message)
    {
        messages.add(message);
    }

}
