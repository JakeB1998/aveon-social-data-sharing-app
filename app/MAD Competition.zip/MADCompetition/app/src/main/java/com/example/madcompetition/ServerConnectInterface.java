package com.example.madcompetition;

import android.util.Log;

import com.example.madcompetition.BackEnd.Account;
import com.example.madcompetition.BackEnd.AccountInformation;
import com.example.madcompetition.BackEnd.AppManager;
import com.example.madcompetition.BackEnd.ClientServerMessage;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;


public class ServerConnectInterface implements Runnable
{
    private static final ServerConnectInterface ourInstance = new ServerConnectInterface();

    public static ServerConnectInterface getInstance() {
        return getOurInstance();
    }
    public static ServerConnectInterface getOurInstance() {
        return ourInstance;
    }

    private ArrayList<String> requestQue;
    private ArrayList<ClientServerMessage> messageQue;
    private Account currentAccount;

    private boolean isConnected;

    private BufferedReader inFromUser;
    private DataInputStream inFromServer;
    private Socket clientSocket;
    private DataOutputStream  outToServer;
    private boolean sendAlive;

    private ServerConnectInterface()
    {
        setConnected(false);
        requestQue = new ArrayList<>(0);
        messageQue = new ArrayList<>(0);



    }

    public boolean connect()
    {
        boolean bool;

        try
        {

            clientSocket = new Socket(ServerContract.SERVER_IP_ADRESS, ServerContract.SERVER_PORT_NUMBER);
            //clientSocket = new Socket("10.135.11.126", ServerContract.SERVER_PORT_NUMBER);
            clientSocket.setTcpNoDelay( true );
            setConnected(true);
            bool = true;
            inFromServer = new DataInputStream( clientSocket.getInputStream());
            outToServer = new DataOutputStream(  clientSocket.getOutputStream());
            AppManager.getInstance().setConnectedToServer(true);

        } catch (UnknownHostException e1)
        {
            AppManager.getInstance().setConnectedToServer(false);
            bool = false;
            // TODO Auto-generated catch block
            e1.printStackTrace();
            Log.e("Server", e1.getMessage());
        } catch (IOException e1)
        {
            AppManager.getInstance().setConnectedToServer(false);
            bool = false;
            // TODO Auto-generated catch block
            e1.printStackTrace();
            Log.e("Server", e1.getMessage());
        }

        return  bool;

    }


    @Override
    public void run()
    {

        ClientServerMessage x = new ClientServerMessage(new AccountInformation(), new AccountInformation(), MessageType.TextToUser, SerializationOperations.serializeObjectToBtyeArray(new Account()));
        requestToSendMessage(x);
        while(true) {

            long time = System.currentTimeMillis();
            long newTime = time + 5000;

            while (messageQue.isEmpty() && requestQue.isEmpty() ) {         //&& time < newTime
                Log.i("Server", Integer.toString(messageQue.size()));
                time = System.currentTimeMillis();

            }


            boolean bool = connect();
            Log.i("Server", "Server Connection Status : " + bool);


            runServerInteraction();

            if (clientSocket.isClosed() == false) {
                try {
                    clientSocket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    public void runServerInteraction()
    {
        Log.i("Server", Integer.toString(messageQue.size()));

        try {
            if (inFromServer.available() > 0)
            {
                Log.i("Server", Integer.toString(clientSocket.getInputStream().available()));

                BufferedReader dsa = new BufferedReader(new InputStreamReader(inFromServer));
                String request = dsa.readLine();
                //outToServer.write(SerializationOperations.serializeObjectToBtyeArray(x));
                outToServer.flush();


                Log.i("Server", request);

                if (request.equals(request)) {


                }

            } else if (requestQue.isEmpty() == false)
            {




            } else if (messageQue.isEmpty() == false)
            {
                ClientServerMessage message = messageQue.get(0);
                ObjectOutputStream zz = new ObjectOutputStream(outToServer);
                zz.writeObject(message);

                messageQue.remove(0);



            } else {


            }

            Log.i("Server", "Server cycle ended");
        } catch (IOException e)
        {
            setConnected(false);

        }


        }


    public void requestToSendMessage(ClientServerMessage message)
    {
        messageQue.add(message);
        //requestQue.add(ServerContract.SEND_MESSAGE_TO_USER);
    }

    public void sendMessage()
    {

        if (messageQue.isEmpty() == false)
        {
            ClientServerMessage message1 = messageQue.get(0);


                // send message
                messageQue.remove(0);

        }
    }

    public void sendNewAccount(Account account)
    {
        requestQue.add(ServerContract.LOG_NEW_ACCOUNT);
        currentAccount = account;

    }

    public void sendAccount()
    {
        // send current account
    }


    public void queSocketClose()
    {
        requestQue.add(ServerContract.DISCONNECT_CODE);
    }


    private void disconnectFromServer()
    {

        Log.e("Server", "Server discconect initiated");
        String  exitMessage = ServerContract.DISCONNECT_CODE;
        String response = "";




            try {
                Log.e("Server", "Started to write exit code to server");

                outToServer.writeBytes(ServerContract.DISCONNECT_CODE + "\n");
                outToServer.flush();
                Log.e("Server", "Wrote exit code to server");

                while (inFromServer.available() == 0)
                {

                }
                Log.e("Server", "Getting Response from server");

                if (inFromServer.available() > 0)
                {
                    String x = inFromServer.readLine();
                    if (x.equals(ServerContract.CONFIRM_RESPONSE))
                    {
                        setConnected(false);
                        try {
                            clientSocket.close();
                            Log.i("Server", "Server disconnected");
                        } catch (IOException e) {
                            e.printStackTrace();
                            Log.i("Server", e.getMessage());
                        }

                    }
                    else
                    {
                        Log.i("Server","Failed to notify and close socket");
                    }
                }
            }
            catch(IOException e)
            {
                Log.i("Server",e.getMessage());

            }





    }

    public boolean isConnected() {
        return isConnected;
    }

    public void setConnected(boolean connected) {
        isConnected = connected;
    }
}
