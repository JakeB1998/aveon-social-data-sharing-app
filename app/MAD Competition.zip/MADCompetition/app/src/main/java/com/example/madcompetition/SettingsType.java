package com.example.madcompetition;

public enum SettingsType
{
    Local,Remote,Requested
}
