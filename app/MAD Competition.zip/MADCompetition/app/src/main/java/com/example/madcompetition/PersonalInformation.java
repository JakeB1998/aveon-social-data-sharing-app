package com.example.madcompetition;

public class PersonalInformation {
}
