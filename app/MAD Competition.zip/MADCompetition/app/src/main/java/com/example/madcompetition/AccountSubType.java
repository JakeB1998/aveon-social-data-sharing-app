package com.example.madcompetition;

public enum AccountSubType
{
    Bussiness, Personal
}
