package com.example.madcompetition.Activties;

import android.os.Bundle;

import com.example.madcompetition.BackEnd.Account;
import com.example.madcompetition.BackEnd.AppManager;
import com.example.madcompetition.BackEnd.Conversation;
import com.example.madcompetition.BackEnd.FileMessage;
import com.example.madcompetition.BackEnd.LocationMessage;
import com.example.madcompetition.BackEnd.PictureMessage;
import com.example.madcompetition.Message;
import com.example.madcompetition.R;
import com.example.madcompetition.TextMessage;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.View;

import java.io.File;
import java.util.ArrayList;

public class ActivityConversationInterface extends AppCompatActivity {

    private AppManager appManager;
    private Account currentAccount;
    private Account responderAccount;
    private Conversation currentConversation;
    private Message[] messages;


    private Account[] recipients;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        appManager = AppManager.getInstance();
        currentAccount = appManager.getCurrentAccountLoggedIn();

        ArrayList<Message> temp = currentConversation.getMessages();
        messages = new Message[temp.size()];
        for (int i =0; i < messages.length; i++)
        {
            messages[i] = temp.get(i);
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conversation_interface);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Bundle extras = getIntent().getExtras();

        if (extras.containsKey("Conversation"))
        {
            currentConversation = (Conversation) extras.getSerializable("Conversation");
            recipients = currentConversation.getAccounts();

            if (recipients.length == 2)
            {
                if (recipients[0].equals(appManager.getCurrentAccountLoggedIn()))
                {
                    currentAccount = recipients[0];
                    responderAccount = recipients[1];
                }
                else if (recipients[1].equals(appManager.getCurrentAccountLoggedIn()))
                {
                    currentAccount = recipients[1];
                    responderAccount = recipients[0];

                }
                else
                {
                    // conversation does not belong to this account
                }
            }
            else if (recipients.length > 2)
            {
                // group message
            }
            else
            {
                //invalid convo
            }
        }

        /*
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

         */
    }

    private boolean dataValidation()
    {
        return  true;
    }

    private void createGui(Message message)
    {
        //createTextMessageGui((TextMessage)message);
        //createPictureMessageGui((PictureMessage)message);
        //createLocationMessage((LocationMessage)message);
        //createFileMessage((FileMessage)message);

    }

    private void createTextMessageGui(TextMessage text)
    {
        Account sender = text.getSender();

    }

    private void createPictureMessageGui(PictureMessage pictureMessage)
    {
        Account sender = pictureMessage.getSender();

    }

    private void createLocationMessage(LocationMessage locationMessage)
    {

    }

    private void createFileMessage(FileMessage message, boolean hostSent)
    {

    }

    private boolean isHostSent(Message message)
    {
        return true;
    }










    /*
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Log.i("Application", "Activity state restored");
    }
    @Override
    protected void onSaveInstanceState(Bundle outState) {

        super.onSaveInstanceState(outState);
        Log.i("Application", "Activity state Saved");
    }

     */

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
