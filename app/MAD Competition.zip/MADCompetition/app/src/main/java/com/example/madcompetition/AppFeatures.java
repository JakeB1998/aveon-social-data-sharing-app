package com.example.madcompetition;

public enum AppFeatures
{
    Location_Data, a,b
}
