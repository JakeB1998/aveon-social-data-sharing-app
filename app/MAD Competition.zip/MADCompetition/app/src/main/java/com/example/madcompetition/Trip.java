package com.example.madcompetition;

public class Trip
{

    private String startAdress;
    private String endAdress;

    private double[] cordinates;


}
