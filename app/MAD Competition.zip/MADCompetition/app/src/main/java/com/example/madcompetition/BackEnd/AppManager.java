package com.example.madcompetition.BackEnd;

import android.content.Context;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import java.time.LocalDate;
import java.util.Calendar;

public class AppManager {
    private static final AppManager ourInstance = new AppManager();

    public static final String NULLABLE_STRING = "--als";

    public static Calendar todaysDate  = Calendar.getInstance();

   public  static AppManager getInstance() {
        return getOurInstance();
    }

    private Account currentAccountLoggedIn;

    private boolean isConnectedToServer;

    public Location locationsFromLastUpdate;


    private AppManager()
    {
        setConnectedToServer(false);

    }

    public static AppManager getOurInstance() {
        return ourInstance;
    }


    public boolean isLoggedIn()
    {
        if (getCurrentAccountLoggedIn() != null)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public boolean isLoggedIn(Account account)
    {
        if (getCurrentAccountLoggedIn() == account)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public Account getCurrentAccountLoggedIn() {
        return currentAccountLoggedIn;
    }

    public void setCurrentAccountLoggedIn(Account currentAccountLoggedIn) {
        this.currentAccountLoggedIn = currentAccountLoggedIn;
        this.currentAccountLoggedIn.setDateLastAccessed(LocalDate.now());
    }

    public boolean checkPermission(String permission)
    {
        boolean bool = false;
        //check permission


        return bool;
    }

    public boolean isConnectedToServer() {
        return isConnectedToServer;
    }

    public void setConnectedToServer(boolean connectedToServer) {
        isConnectedToServer = connectedToServer;
    }

    public boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }


}
