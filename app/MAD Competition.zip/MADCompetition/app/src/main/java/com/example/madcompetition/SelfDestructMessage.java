package com.example.madcompetition;

public class SelfDestructMessage implements Runnable
{
    private int selfDestructTimeDelay;

    private boolean selfDestructImmediate;
    private boolean selfDestructCompleted;

    public SelfDestructMessage()
    {
        selfDestructCompleted = false;

    }
    public SelfDestructMessage(int timeDelay)
    {
       this();
        this.selfDestructTimeDelay = timeDelay;

    }
    public SelfDestructMessage(boolean selfDestructImmediate)
    {
        this();
       this.selfDestructImmediate = selfDestructImmediate;
    }
    public SelfDestructMessage(boolean selfDestructImmediate, int timeDelay, Message message)
    {
        this();
        this.selfDestructImmediate = selfDestructImmediate;
    }


    @Override
    public void run()
    {
        try
        {
            Thread.sleep(selfDestructTimeDelay * 1000);

            selfDestructCompleted = true;
        } catch (InterruptedException e)
        {
            e.printStackTrace();
        }

    }
}
