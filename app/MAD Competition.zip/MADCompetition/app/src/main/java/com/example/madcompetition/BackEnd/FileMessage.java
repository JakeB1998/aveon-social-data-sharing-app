package com.example.madcompetition.BackEnd;

import com.example.madcompetition.Message;

public class FileMessage extends Message {

    public FileMessage()
    {
        super();
    }

}
