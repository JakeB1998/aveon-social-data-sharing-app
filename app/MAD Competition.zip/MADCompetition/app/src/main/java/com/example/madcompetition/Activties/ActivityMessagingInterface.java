package com.example.madcompetition.Activties;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.madcompetition.BackEnd.AppManager;
import com.example.madcompetition.BackEnd.Account;
import com.example.madcompetition.BackEnd.Conversation;
import com.example.madcompetition.Message;
import com.example.madcompetition.R;
import com.example.madcompetition.TextMessage;

import java.io.Serializable;
import java.util.ArrayList;

public class ActivityMessagingInterface extends AppCompatActivity
{
    private ArrayList<Conversation> conversations = new ArrayList<>(0);

    private Account loggedInAccount;
    private ViewGroup conversationDisplay;
    private LinearLayout myLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_messaging_interface);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        toolbar.setBackgroundColor(Color.GRAY);





        conversations = new ArrayList<>(0);
        myLayout = findViewById(R.id.ConversationContrainer);



       loadConversations(this);

       /*
       Conversation c = new Conversation();
       TextMessage t = new TextMessage("NEEEEEEERRRRRRRRRDDDDD", new Account("David"), new Account("David"));
       t.setDateSent(LocalDate.now());
       t.setTimeSent(LocalTime.now());
       c.addMessage(t);
       handleConversationUI(c);



        c = new Conversation();
        t = new TextMessage("Hubba wubba Do", new Account("Alex P"), new Account("Alex P"));
        t.setDateSent(LocalDate.now());
        t.setTimeSent(LocalTime.now().minusMinutes(12));
        c.addMessage(t);
        handleConversationUI(c);

        c = new Conversation();
        t = new TextMessage("ISU though", new Account("Sarah B"), new Account("Sarah B"));
        t.setDateSent(LocalDate.now().minusDays(1));
        t.setTimeSent(LocalTime.now());
        c.addMessage(t);
        handleConversationUI(c);

        c = new Conversation();
        t = new TextMessage("The socks are kinda bad", new Account("Bryant"), new Account("Bryant"));
        t.setDateSent(LocalDate.now().minusDays(2));
        t.setTimeSent(LocalTime.now());
        c.addMessage(t);
        handleConversationUI(c);

        c = new Conversation();
        t = new TextMessage("Hi", new Account("Jay"), new Account("Jay"));
        t.setDateSent(LocalDate.now().minusDays(3));
        t.setTimeSent(LocalTime.now());
        c.addMessage(t);
        handleConversationUI(c);

        c = new Conversation();
        t = new TextMessage("This is kinda cool", new Account("Andrew"), new Account("Andrew"));
        t.setDateSent(LocalDate.now().minusDays(4));
        t.setTimeSent(LocalTime.now());
        c.addMessage(t);
        handleConversationUI(c);

        c = new Conversation();
        t = new TextMessage("I like apple sauce", new Account("Nina"), new Account("Nina"));
        t.setDateSent(LocalDate.now().minusDays(5));
        t.setTimeSent(LocalTime.now());
        c.addMessage(t);
        handleConversationUI(c);

        */





       // this.loadConversations(this);
    }


    public void loadConversations(Context context)
    {
        loggedInAccount = AppManager.getInstance().getCurrentAccountLoggedIn();
        if (loggedInAccount.getConversations() != null) {
            conversations = loggedInAccount.getConversations();
        }





        int index = 0;
        if (conversations.size() > 0) {
            for (Conversation convo : conversations) {
                this.handleConversationUI(convo);
                index++;

            }
        }

    }

    public void handleConversationUI(Conversation convo)
    {
        final Conversation convoNew = convo;

        /*
        Message message = new Message(new Account("Alex", LocalDate.now()), new Account("Adam",LocalDate.now()), SerializationOperations.serializeObjectToBtyeArray(new TextMessage("I am Gay")), MessageType.TextToUser);
        byte[] x = SerializationOperations.serializeObjectToBtyeArray(message);
        Message newMessage = (Message) SerializationOperations.deserializeToObject(x);

        message.setDateSent(LocalDate.now());
        message.setTimeSent(LocalTime.now());

        TextMessage newText =  (TextMessage) SerializationOperations.deserializeToObject(newMessage.getDataPayload());

         */

/*
        Message newMessage = new TextMessage("Aids", new Account(), new Account());

        byte[] message = SerializationOperations.serializeObjectToBtyeArray(newMessage);
        TextMessage newText = (TextMessage) SerializationOperations.deserializeToObject(message);

 */

        Message m = convo.getMessages().get(convo.getMessages().size() - 1);
        TextMessage newText = (TextMessage)m;





        int layoutHeight = 300;
        int layoutWidth = myLayout.getLayoutParams().width;



        TextView messagePreview = new TextView(this);
        messagePreview.setText(newText.getMessage());
        messagePreview.setMinHeight(100);
        messagePreview.setWidth(500);
        messagePreview.setTranslationX(50f);

        messagePreview.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView datePreview = new TextView(this);
        datePreview.setText(newText.getConversationDateDisplay());
        datePreview.setMinHeight(50);
        datePreview.setMinimumWidth(50);
        datePreview.setTranslationY(15f);

        datePreview.setPadding(0,0,0,25);
        datePreview.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout horLayout = new LinearLayout(this);
        horLayout.setOrientation(LinearLayout.HORIZONTAL);
        horLayout.setLayoutParams(new LinearLayout.LayoutParams(layoutWidth,layoutHeight));
        Drawable draw = ContextCompat.getDrawable(this,R.drawable.conversation_ui_outline);
        horLayout.setBackground(draw);
       // horLayout.setBackgroundColor(Color.argb(43,203,213,213));

        horLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("Event", "Layout was cliecked");
                loadConversationActivity(convoNew);
            }
        });




        LinearLayout newl = new LinearLayout(this);
        newl.setOrientation(LinearLayout.VERTICAL);

        newl.setLayoutParams(new LinearLayout.LayoutParams(myLayout.getLayoutParams().width,400));
        TextView text = new TextView((this));
        text.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        text.setHeight(300);
        text.setWidth(200);

        text.setText(newText.getSender().getFullName());
        text.setPadding(50,100,0,0);
        text.setTextSize(20f);
        //newl.addView(text);

        ImageButton profileImage = new ImageButton(this);
        profileImage.setMinimumHeight(200);
        profileImage.setMinimumWidth(200);
        profileImage.setTranslationY(50f);
        profileImage.setBackground(getResources().getDrawable(R.mipmap.default_profile_picture, getTheme()));
        horLayout.addView(profileImage);
        horLayout.addView(text);
        horLayout.addView(messagePreview);
        newl.addView(datePreview);



        View v1 = new View(this);
        v1.setLayoutParams(new ViewGroup.LayoutParams(getApplicationContext().getResources().getDisplayMetrics().widthPixels / 2 + 100,1));
        v1.setX(getApplicationContext().getResources().getDisplayMetrics().widthPixels / 5);




        v1.setBackgroundColor(Color.BLACK);
        horLayout.addView(newl);
        myLayout.addView(horLayout);
        myLayout.addView(v1);
    }


    public void loadConversationActivity(Conversation conversation)
    {
        Intent intent = new Intent(this, ActivityConversationInterface.class);
        intent.putExtra("Conversation", (Serializable)conversation);
        startActivity(intent);


    }





}
