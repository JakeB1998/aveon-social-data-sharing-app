package com.example.madcompetition;

public enum MediaType {
    Text,Picture,Location
}
