package com.example.madcompetition;

public enum AccountType

{
    Admin,User

}
