package com.example.madcompetition;

public enum ActivityStatus {
    Online, Offline,Away
}
