package com.example.madcompetition;

public enum CredentialsType
{
    Locked,Unlocked
}
