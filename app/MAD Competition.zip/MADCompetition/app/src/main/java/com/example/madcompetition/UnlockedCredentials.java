package com.example.madcompetition;

import com.example.madcompetition.BackEnd.Credentials;

public class UnlockedCredentials extends Credentials
{

}
