package com.example.madcompetition;

public enum MessageType
{
    TextToUser,DataLogToServer, DataLogToUser, LocationToServer, LocationToUser
}
