package com.example.madcompetition;

import com.example.madcompetition.BackEnd.Account;

public class UserAccount extends Account
{
    public UserAccount()
    {
        super();
    }

}
