package com.example.madcompetition;

public class ServerContract
{
    public final static int SERVER_PORT_NUMBER = 6788;
    public final static String SERVER_IP_ADRESS = "10.0.0.43";
    public final static String SERVER_HOST_NAME = "LAPTOP-8JD1SVPV";
    public final static String WAIT_FOR_RESPONSE = "-232q";
    public final static String READY_FOR_RESPONSE = "-143q";

    public final static String SEND_MESSAGE_TO_USER = "-1423q";
    public final static String SEND_LOCATION_TO_USER = "-1321q";
    public final static String LOG_DATA_TO_SERVER = "-9201q";
    public final static String LOG_NEW_ACCOUNT = "-12a3";
    public final static String UPDATE_DATABASE = "-13qwd";

    public final static String DISCONNECT_CODE = "-1021q";
    public final static String CONFIRM_RESPONSE = "Confirm";
    public final static String INVALID_RESPONSE = "-1aps";
    public final static String ALIVE = "-112ps";
    public final static String HANDLE_REQUEST = "asfe-1";
}
